package García_Aarón;

public class RelojDigital {

    int horas;
    int minutos;
    int segundos;
    double batería;
//Método constructor

    public RelojDigital(int horas, int minutos, int segundos, double batería) {
        //this
        this.horas = horas;
        this.minutos = minutos;
        this.segundos = segundos;
        this.batería = batería;
    }

    RelojDigital(int i, int i0, int i1, int i2, int i3) {

    }

    public void revisarHora(int horas, int minutos, int segundos) {
        if (horas < 1 || horas > 12) {
            horas = 1;
        }
        if (minutos < 1 || minutos > 59) {
            minutos = 1;
        }
        if (segundos < 1 || segundos > 59) {
            segundos = 1;
        }
    }

    public void mostrarHora(int horas, int minutos, int segundos, double batería) {
        System.out.println(this.horas + this.minutos + this.segundos);
        if (this.horas < 2 || this.minutos < 2 || this.segundos < 2) {
        } else {
            double name = this.batería - 10;
        }

    }

    public void cargarBatería(double batería) {
        double name = this.batería + 10;

    }

    public void alarma(int horas, int minutos, int segundos) {
        if (horas < 1 || horas < 12) {
        }
        if (minutos < 1 || minutos > 59) {
        }
        if (segundos < 1 || minutos > 59) {

        }

    }

    public void encender(int horas, int minutos, int segundos) {
        System.out.println("Encendiendo reloj..." + this.horas);
    }

    public void apagar() {
        System.out.println("Reloj apagado");

    }

}
