package García_Aarón;

public class testMaquinaAzar {

    public static void main(String[] args) {

    }

}
