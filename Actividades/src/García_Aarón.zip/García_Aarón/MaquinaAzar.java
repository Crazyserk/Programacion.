package García_Aarón;

public class MaquinaAzar {

    double peso;
    double anchura;
    double largo;
    double dinero;
    int rizquierda, rcentro, rderecha;

// Método constructor
    public MaquinaAzar(double peso, double anchura, double largo, double dinero, int rizquierda, int rcentro, int rderecha) {
        this.peso = peso;
        this.anchura = anchura;
        this.largo = largo;
        this.dinero = 10000;
        this.rizquierda = rizquierda;
        this.rcentro = rcentro;
        this.rderecha = rderecha;
    }

    //MÉTODO JUGAR
    public void jugar() {
        System.out.println(this.dinero + 25);

    }

}
