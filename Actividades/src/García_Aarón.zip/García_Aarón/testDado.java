package García_Aarón;

public class testDado {

    public static void main(String[] args) {
        testDado dado1= new testDado ();
        System.out.println("Ha salido un" );
        //mostramos el resultado
        
        

    }

}
