package García_Aarón;

public class RelojDigitaltest {

    public static void main(String[] args) {
              RelojDigital rolex = new RelojDigital(10,23,45,98,7);
              System.out.println("");
    }

}
