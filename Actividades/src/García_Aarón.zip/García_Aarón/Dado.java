package García_Aarón;

public class Dado {
//Propiedades (atributos)

    int caras;
    String color;
    double peso;
//Método constructor

    public Dado(double peso, String color, int caras) {
        this.color = color;
        this.peso = peso;
        this.caras = 6;
        //fuera del constructor
        this.caras = (int) (Math.random() * 6 + 1);
    }
    //método de lanzar

    public void lanzar() {
       
        System.out.println("Ha salido un " + this.caras);

    }
}
